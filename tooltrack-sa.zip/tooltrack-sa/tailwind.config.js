/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: { brand: { DEFAULT: "#F26A1B", dark: "#D55A10" } } } }, // orange from the logo
  plugins: [],
};
