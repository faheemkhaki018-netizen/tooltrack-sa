module.exports = {
  root: true,
  env: { browser: true, es2022: true },
  extends: ["eslint:recommended", "plugin:@typescript-eslint/recommended", "plugin:react-hooks/recommended"],
  ignorePatterns: ["dist", "supabase", "*.config.*", ".eslintrc.cjs"], // supabase/ is Deno code
  parser: "@typescript-eslint/parser",
  plugins: ["react-refresh"],
  rules: { "react-refresh/only-export-components": ["warn", { allowConstantExport: true }] },
};
