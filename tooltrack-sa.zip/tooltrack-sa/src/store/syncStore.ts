import { create } from "zustand";
import { NetworkError, countPending, runSync } from "../lib/sync";

type Status = "idle" | "syncing" | "offline" | "error";
interface SyncState {
  status: Status;
  lastSyncedAt: string | null;
  pending: number;
  rejected: number;
  error: string | null;
  syncNow: () => Promise<void>;
}

let running = false, queued = false, attempt = 0;
let retryTimer: ReturnType<typeof setTimeout> | undefined;
let debounceTimer: ReturnType<typeof setTimeout> | undefined;

export const useSync = create<SyncState>()((set, get) => ({
  status: "idle", lastSyncedAt: null, pending: 0, rejected: 0, error: null,

  syncNow: async () => {
    if (running) { queued = true; return; } // a write landed mid-sync: run again afterwards
    running = true;
    clearTimeout(retryTimer);
    set({ status: "syncing", error: null });
    try {
      await runSync();
      attempt = 0;
      set({ status: "idle", lastSyncedAt: new Date().toISOString(), ...(await countPending()) });
    } catch (e) {
      const counts = await countPending();
      if (e instanceof NetworkError) {
        attempt += 1; // exponential backoff: 4s, 8s, ... capped at 60s
        retryTimer = setTimeout(() => void get().syncNow(), Math.min(60_000, 2000 * 2 ** attempt));
        set({ status: "offline", ...counts });
      } else {
        set({ status: "error", error: e instanceof Error ? e.message : String(e), ...counts });
      }
    } finally {
      running = false;
      if (queued) { queued = false; void get().syncNow(); }
    }
  },
}));

/** Call after any local write: debounced so bursts of edits become one sync. */
export function requestSync() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => void useSync.getState().syncNow(), 800);
}

/** Wire up automatic triggers once at app start; returns a cleanup function. */
export function startSyncTriggers(): () => void {
  const go = () => { attempt = 0; void useSync.getState().syncNow(); };
  const onVisible = () => { if (document.visibilityState === "visible") go(); };
  window.addEventListener("online", go);
  document.addEventListener("visibilitychange", onVisible);
  const interval = setInterval(go, 60_000);
  go();
  return () => {
    window.removeEventListener("online", go);
    document.removeEventListener("visibilitychange", onVisible);
    clearInterval(interval);
    clearTimeout(retryTimer);
  };
}
