import { create } from "zustand";
import { DEMO_COMPANY, db, getMeta, setMeta } from "../lib/db";
import { supabase } from "../lib/supabase";
import { countPending } from "../lib/sync";

type Mode = "demo" | "cloud" | null;
interface SessionState {
  ready: boolean;
  mode: Mode;
  companyId: string | null;
  init: () => Promise<void>;
  startDemo: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, companyName: string, fullName: string) => Promise<{ needsConfirmation: boolean }>;
  signOut: (force?: boolean) => Promise<void>;
}

const client = () => {
  if (!supabase) throw new Error("Cloud sync isn't configured. Continue in demo mode instead.");
  return supabase;
};

// register_company is idempotent, so calling it after every login also covers the
// "Confirm email" flow, where there is no session at sign-up time.
async function connect(): Promise<string> {
  const sb = client();
  const { data: { user } } = await sb.auth.getUser();
  const m = (user?.user_metadata ?? {}) as { company_name?: string; full_name?: string };
  const { data, error } = await sb.rpc("register_company", { p_company_name: m.company_name ?? "My Company", p_full_name: m.full_name ?? "" });
  if (error) throw new Error(error.message);
  await setMeta("mode", "cloud");
  await setMeta("companyId", data);
  return data as string;
}

export const useSession = create<SessionState>()((set, get) => ({
  ready: false, mode: null, companyId: null,

  // Reads local state only, so the app opens offline without needing the network.
  init: async () => {
    const companyId = (await getMeta<string>("companyId")) ?? null;
    set({ ready: true, companyId, mode: companyId ? ((await getMeta<Mode>("mode")) ?? null) : null });
  },

  startDemo: async () => {
    await setMeta("mode", "demo");
    await setMeta("companyId", DEMO_COMPANY);
    set({ mode: "demo", companyId: DEMO_COMPANY });
  },

  signIn: async (email, password) => {
    const { error } = await client().auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
    set({ mode: "cloud", companyId: await connect() });
  },

  signUp: async (email, password, companyName, fullName) => {
    const { data, error } = await client().auth.signUp({
      email, password, options: { data: { company_name: companyName, full_name: fullName } },
    });
    if (error) throw new Error(error.message);
    if (!data.session) return { needsConfirmation: true }; // company is created on first sign-in
    set({ mode: "cloud", companyId: await connect() });
    return { needsConfirmation: false };
  },

  // Refuses to wipe unsynced work unless forced. The UI should catch "UNSYNCED" and confirm.
  signOut: async (force = false) => {
    if (get().mode === "cloud") {
      if (!force && (await countPending()).pending > 0) throw new Error("UNSYNCED");
      await supabase?.auth.signOut();
      await db.transaction("rw", db.tools, db.workers, db.checkouts, db.meta, async () => {
        for (const t of [db.tools, db.workers, db.checkouts]) await t.where("company_id").notEqual(DEMO_COMPANY).delete();
        await db.meta.bulkDelete(["mode", "companyId", "company", "cursor:workers", "cursor:tools", "cursor:checkouts"]);
      });
    } else {
      await db.meta.bulkDelete(["mode", "companyId"]); // demo data stays for next time
    }
    set({ mode: null, companyId: null });
  },
}));
