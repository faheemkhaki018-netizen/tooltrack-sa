import { Component, type ErrorInfo, type ReactNode } from "react";

export default class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Unhandled UI error", error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="mx-auto flex min-h-full max-w-md flex-col justify-center gap-4 p-6">
        <h1 className="text-2xl font-extrabold">Something broke on this screen</h1>
        <p className="text-stone-700">Your tools and check-outs are saved on this device. Reload to carry on.</p>
        <button className="btn btn-primary" onClick={() => window.location.reload()}>Reload the app</button>
      </div>
    );
  }
}
