import { forwardRef, useEffect, type InputHTMLAttributes, type ReactNode } from "react";
import type { ToolStatus } from "../lib/db";

const STATUS: Record<ToolStatus, { label: string; cls: string }> = {
  available: { label: "Available", cls: "bg-emerald-700 text-white" },
  checked_out: { label: "Checked out", cls: "bg-brand text-stone-900" },
  maintenance: { label: "In repair", cls: "bg-sky-700 text-white" },
  lost: { label: "Lost", cls: "bg-red-700 text-white" },
};

export function StatusBadge({ status }: { status: ToolStatus }) {
  const { label, cls } = STATUS[status];
  return <span className={`rounded px-2 py-0.5 text-sm font-bold ${cls}`}>{label}</span>;
}

export function Logo({ className = "", full = false }: { className?: string; full?: boolean }) {
  if (full) return <img src="/logo-full.png" alt="ToolTrack SA. Track. Protect. Deliver." className={className} />;
  return (
    <span className={`inline-flex items-center gap-2 text-xl font-extrabold tracking-tight ${className}`}>
      <img src="/logo-mark.png" alt="" width={36} height={36} className="h-9 w-9" />
      <span>ToolTrack <span className="text-brand">SA</span></span>
    </span>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div aria-hidden="true" className={`animate-pulse rounded-lg bg-stone-300 ${className}`} />;
}

export function EmptyState({ title, body, action }: { title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="card flex flex-col items-start gap-3 py-8">
      <h2 className="text-xl font-extrabold">{title}</h2>
      {body && <p className="text-stone-700">{body}</p>}
      {action}
    </div>
  );
}

export function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-stone-900/60" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}
        className="max-h-[90%] w-full max-w-md overflow-y-auto rounded-t-2xl bg-white p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-xl font-extrabold">{title}</h2>
          <button className="btn btn-ghost min-h-10 px-3" onClick={onClose} aria-label="Close">Close</button>
        </div>
        {children}
      </div>
    </div>
  );
}

type FieldProps = { label: string; error?: string } & InputHTMLAttributes<HTMLInputElement>;
export const Field = forwardRef<HTMLInputElement, FieldProps>(({ label, error, ...rest }, ref) => (
  <label className="block text-base font-semibold">
    {label}
    <input ref={ref} className="input font-normal" {...rest} />
    {error && <span role="alert" className="mt-1 block text-sm font-semibold text-red-700">{error}</span>}
  </label>
));
Field.displayName = "Field";
