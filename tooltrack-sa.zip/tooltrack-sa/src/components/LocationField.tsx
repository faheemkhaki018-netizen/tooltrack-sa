import type { LocationStatus } from "../lib/geo";

const TEXT: Record<LocationStatus, string> = {
  idle: "Location will be recorded",
  locating: "Locating…",
  captured: "Location captured",
  unavailable: "Location unavailable. Continuing without it.",
};

function Pin() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
      <path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z" />
    </svg>
  );
}

export default function LocationField({ enabled, onChange, status }: { enabled: boolean; onChange: (v: boolean) => void; status: LocationStatus }) {
  const tone = !enabled ? "text-stone-600" : status === "captured" ? "text-emerald-800" : status === "unavailable" ? "text-red-700" : "text-stone-800";
  return (
    <div className="rounded-lg border border-stone-300 bg-stone-50 p-3">
      <label className="flex items-center gap-3 font-semibold">
        <input type="checkbox" className="h-6 w-6 accent-orange-600" checked={enabled} disabled={status === "locating"}
          onChange={(e) => onChange(e.target.checked)} />
        Record location for this action
      </label>
      <p role="status" aria-live="polite" className={`mt-2 flex items-center gap-2 text-sm font-semibold ${tone} ${status === "locating" ? "animate-pulse" : ""}`}>
        <Pin />
        {enabled ? TEXT[status] : "Location off for this action"}
      </p>
      {enabled && <p className="mt-1 text-sm text-stone-700">Location is captured for tool audit purposes only.</p>}
    </div>
  );
}
