import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "../lib/db";
import { buildReport } from "../lib/report";
import { downloadBlob, sharePdf, whatsappLink } from "../lib/share";
import { useSession } from "../store/session";

/** With toolId: history of that tool (+ WhatsApp reminder to whoever has it). Without: the full register. */
export default function ReportButtons({ toolId }: { toolId?: string }) {
  const companyId = useSession((s) => s.companyId) ?? "";
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const reminder = useLiveQuery(async () => {
    if (!toolId) return null;
    const tool = await db.tools.get(toolId);
    const open = await db.checkouts.where("tool_id").equals(toolId).filter((c) => c.checked_in_at === null).first();
    const worker = open ? await db.workers.get(open.worker_id) : undefined;
    if (!tool || !open || !worker?.phone) return null;
    const text = `Hi ${worker.name}, please bring back ${tool.tool_code} ${tool.name}. It went out on ${new Date(open.checked_out_at).toLocaleDateString("en-ZA")}.`;
    return { name: worker.name, url: whatsappLink(worker.phone, text) };
  }, [toolId]);

  const run = async (share: boolean) => {
    setBusy(true);
    setMessage(null);
    try {
      const { blob, filename, summary } = await buildReport({ companyId, toolId });
      if (!share) downloadBlob(blob, filename);
      else if ((await sharePdf(blob, filename, summary)) === "fallback") {
        setMessage("The PDF was downloaded. Attach it in the WhatsApp chat that opened.");
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Couldn't create the PDF. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card space-y-2">
      <h2 className="text-lg font-extrabold">{toolId ? "Records for this tool" : "Reports"}</h2>
      <p className="text-stone-700">
        {toolId ? "Every check-out and return, ready for an insurance claim or audit." : "Every tool, who has it now, and the full check-out history."}
      </p>
      <button className="btn btn-ghost w-full" disabled={busy} onClick={() => void run(false)}>
        {busy ? "Preparing PDF…" : "Download PDF"}
      </button>
      <button className="btn btn-ghost w-full" disabled={busy} onClick={() => void run(true)}>Share on WhatsApp</button>
      {reminder && (
        <a className="btn btn-primary w-full" href={reminder.url} target="_blank" rel="noreferrer">Remind {reminder.name} on WhatsApp</a>
      )}
      {message && <p role="status" className="font-semibold">{message}</p>}
    </section>
  );
}
