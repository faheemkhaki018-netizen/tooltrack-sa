import type { Checkout, Worker } from "../lib/db";

const mapUrl = (lat: number, lng: number) => `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
const day = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString("en-ZA") : "-");

function Place({ label, lat, lng, acc }: { label: string; lat?: number | null; lng?: number | null; acc?: number | null }) {
  if (lat == null || lng == null) return <p className="text-sm text-stone-600">{label}: no location recorded</p>;
  return (
    <p className="text-sm">
      {label}: <span className="font-mono">{lat.toFixed(5)}, {lng.toFixed(5)}</span>
      {acc != null && ` (±${Math.round(acc)} m)`}{" "}
      <a className="font-bold underline" href={mapUrl(lat, lng)} target="_blank" rel="noopener noreferrer">View on map</a>
    </p>
  );
}

export default function HistoryList({ checkouts, workers }: { checkouts: Checkout[]; workers: Worker[] }) {
  if (checkouts.length === 0) return null;
  const name = (id: string) => workers.find((w) => w.id === id)?.name ?? "Unknown worker";
  return (
    <section className="card space-y-3">
      <h2 className="text-lg font-extrabold">History</h2>
      <ul className="space-y-3">
        {checkouts.map((c) => (
          <li key={c.id} className="border-t border-stone-200 pt-3 first:border-0 first:pt-0">
            <p className="font-bold">{name(c.worker_id)}</p>
            <p className="text-sm">Out {day(c.checked_out_at)}, back {day(c.checked_in_at)}</p>
            <Place label="Out" lat={c.latitude} lng={c.longitude} acc={c.location_accuracy} />
            {c.checked_in_at && <Place label="Back" lat={c.in_latitude} lng={c.in_longitude} acc={c.in_location_accuracy} />}
          </li>
        ))}
      </ul>
    </section>
  );
}
