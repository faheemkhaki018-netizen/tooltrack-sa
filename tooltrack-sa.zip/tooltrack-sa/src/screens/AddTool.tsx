import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Field } from "../components/ui";
import { createTool } from "../lib/repo";

const schema = z.object({
  name: z.string().trim().min(2, "Give the tool a name"),
  category: z.string().trim().optional(),
  serial_number: z.string().trim().optional(),
  notes: z.string().trim().max(500, "Keep notes under 500 characters").optional(),
});
type Values = z.infer<typeof schema>;

// Shrinks phone photos to ~1024px JPEG so they store and upload quickly on poor connections.
async function toDataUrl(file: File, max = 1024): Promise<string> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close();
  return c.toDataURL("image/jpeg", 0.8);
}

export default function AddTool() {
  const nav = useNavigate();
  const [photo, setPhoto] = useState<string | null>(null);
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<Values>({ resolver: zodResolver(schema) });

  const onPhoto = async (file?: File) => {
    if (!file) return;
    try { setPhoto(await toDataUrl(file)); } catch { setError("root", { message: "That photo couldn't be read. Try another." }); }
  };

  const submit = handleSubmit(async (v) => {
    try {
      const tool = await createTool({ ...v, photo_url: photo ?? undefined });
      nav(`/tool/${tool.id}`, { replace: true }); // next step: print the QR label
    } catch (e) { setError("root", { message: e instanceof Error ? e.message : "Could not save the tool" }); }
  });

  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <h1 className="text-2xl font-extrabold">Add a tool</h1>
      <Field label="Tool name" placeholder="e.g. Makita 18V drill" error={errors.name?.message} {...register("name")} />
      <Field label="Category (optional)" placeholder="e.g. Power tools" {...register("category")} />
      <Field label="Serial number (optional)" {...register("serial_number")} />
      <label className="block text-base font-semibold">
        Notes (optional)
        <textarea className="input" rows={3} {...register("notes")} />
        {errors.notes && <span role="alert" className="text-sm font-semibold text-red-700">{errors.notes.message}</span>}
      </label>
      <div>
        <label className="btn btn-ghost w-full cursor-pointer">
          {photo ? "Retake photo" : "Take or choose a photo"}
          <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => void onPhoto(e.target.files?.[0])} />
        </label>
        {photo && <img src={photo} alt="Tool preview" className="mt-2 h-40 w-full rounded-lg object-cover" />}
      </div>
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Save tool</button>
    </form>
  );
}
