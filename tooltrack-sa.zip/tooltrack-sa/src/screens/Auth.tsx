import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Field, Logo } from "../components/ui";
import { useSession } from "../store/session";

const loginSchema = z.object({
  email: z.string().trim().email("Enter a valid email address"),
  password: z.string().min(8, "Use at least 8 characters"),
});
const registerSchema = loginSchema.extend({
  fullName: z.string().trim().min(2, "Enter your name"),
  companyName: z.string().trim().min(2, "Enter your business name"),
});
type LoginValues = z.infer<typeof loginSchema>;
type RegisterValues = z.infer<typeof registerSchema>;

const msg = (e: unknown, fallback: string) => (e instanceof Error ? e.message : fallback);

function LoginForm() {
  const signIn = useSession((s) => s.signIn);
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<LoginValues>({ resolver: zodResolver(loginSchema) });
  const submit = handleSubmit(async (v) => {
    try { await signIn(v.email, v.password); } catch (e) { setError("root", { message: msg(e, "Could not sign in") }); }
  });
  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register("email")} />
      <Field label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register("password")} />
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Sign in</button>
    </form>
  );
}

function RegisterForm() {
  const signUp = useSession((s) => s.signUp);
  const [notice, setNotice] = useState<string | null>(null);
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<RegisterValues>({ resolver: zodResolver(registerSchema) });
  const submit = handleSubmit(async (v) => {
    try {
      const { needsConfirmation } = await signUp(v.email, v.password, v.companyName, v.fullName);
      if (needsConfirmation) setNotice("Check your email to confirm your address, then sign in.");
    } catch (e) { setError("root", { message: msg(e, "Could not create the account") }); }
  });
  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <Field label="Your name" autoComplete="name" error={errors.fullName?.message} {...register("fullName")} />
      <Field label="Business name" autoComplete="organization" error={errors.companyName?.message} {...register("companyName")} />
      <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register("email")} />
      <Field label="Password" type="password" autoComplete="new-password" error={errors.password?.message} {...register("password")} />
      {notice && <p role="status" className="font-semibold text-emerald-800">{notice}</p>}
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Create account</button>
    </form>
  );
}

export default function Auth() {
  const [tab, setTab] = useState<"login" | "register">("login");
  const startDemo = useSession((s) => s.startDemo);
  return (
    <div className="mx-auto flex min-h-full max-w-md flex-col gap-5 p-5 pt-10">
      <Logo full className="mx-auto w-full max-w-xs" />
      <h1 className="text-3xl font-extrabold leading-tight">Know where every tool is, even without signal.</h1>
      <div className="grid grid-cols-2 border-2 border-stone-900">
        {(["login", "register"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} aria-pressed={tab === t}
            className={`py-3 text-base font-bold ${tab === t ? "bg-stone-900 text-brand" : "bg-white"}`}>
            {t === "login" ? "Sign in" : "New business"}
          </button>
        ))}
      </div>
      {tab === "login" ? <LoginForm /> : <RegisterForm />}
      <div className="border-t-2 border-stone-300 pt-4">
        <p className="mb-2 text-stone-700">Just looking? Everything works on this device, with no account.</p>
        <button className="btn btn-ghost w-full" onClick={() => void startDemo()}>Continue in demo mode</button>
      </div>
    </div>
  );
}
