import { useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useParams } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLiveQuery } from "dexie-react-hooks";
import { QRCodeSVG } from "qrcode.react";
import { z } from "zod";
import { EmptyState, Field, Modal, Skeleton, StatusBadge } from "../components/ui";
import { db, type Worker } from "../lib/db";
import { checkIn, checkOut, createWorker } from "../lib/repo";
import { useSession } from "../store/session";
import ReportButtons from "../components/ReportButtons";
import HistoryList from "../components/HistoryList";
import LocationField from "../components/LocationField";
import { useLocationCapture } from "../lib/geo";

const outSchema = z.object({
  workerId: z.string().uuid("Choose who is taking the tool"),
  dueAt: z.string().optional(),
  condition: z.string().trim().optional(),
});
const workerSchema = z.object({ name: z.string().trim().min(2, "Enter a name"), phone: z.string().trim().optional() });
const inSchema = z.object({ condition: z.string().trim().optional() });

const errText = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong");

function NewWorkerForm({ onCreated }: { onCreated: (w: Worker) => void }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<z.infer<typeof workerSchema>>({ resolver: zodResolver(workerSchema) });
  const submit = handleSubmit(async (v) => {
    try { onCreated(await createWorker(v)); } catch (e) { setError("root", { message: errText(e) }); }
  });
  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <Field label="Worker name" error={errors.name?.message} {...register("name")} />
      <Field label="Phone (optional)" type="tel" {...register("phone")} />
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Add worker</button>
    </form>
  );
}

function CheckOutForm({ toolId, workers, defaultWorkerId, onAdd, onDone }:
  { toolId: string; workers: Worker[]; defaultWorkerId?: string; onAdd: () => void; onDone: () => void }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } =
    useForm<z.infer<typeof outSchema>>({ resolver: zodResolver(outSchema), defaultValues: { workerId: defaultWorkerId ?? "" } });
  const [useLoc, setUseLoc] = useState(true);
  const geo = useLocationCapture();
  const submit = handleSubmit(async (v) => {
    try {
      const location = await geo.locate(useLoc); // never throws: a GPS failure just means no location
      await checkOut(toolId, v.workerId, { dueAt: v.dueAt ? new Date(`${v.dueAt}T17:00`).toISOString() : undefined, condition: v.condition || undefined, location });
      onDone();
    } catch (e) { setError("root", { message: errText(e) }); }
  });
  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <label className="block text-base font-semibold">
        Taken by
        <select className="input" {...register("workerId")}>
          <option value="">Choose a worker</option>
          {workers.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
        </select>
        {errors.workerId && <span role="alert" className="text-sm font-semibold text-red-700">{errors.workerId.message}</span>}
      </label>
      <button type="button" className="font-bold underline" onClick={onAdd}>Add a new worker</button>
      <Field label="Due back (optional)" type="date" {...register("dueAt")} />
      <Field label="Condition now (optional)" placeholder="e.g. Good, small scratch on case" {...register("condition")} />
      <LocationField enabled={useLoc} onChange={setUseLoc} status={geo.status} />
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Check out</button>
    </form>
  );
}

function CheckInForm({ toolId, onDone }: { toolId: string; onDone: () => void }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<z.infer<typeof inSchema>>({ resolver: zodResolver(inSchema) });
  const [useLoc, setUseLoc] = useState(true);
  const geo = useLocationCapture();
  const submit = handleSubmit(async (v) => {
    try {
      const location = await geo.locate(useLoc);
      await checkIn(toolId, { condition: v.condition || undefined, location });
      onDone();
    } catch (e) { setError("root", { message: errText(e) }); }
  });
  return (
    <form className="space-y-3" onSubmit={submit} noValidate>
      <Field label="Condition on return (optional)" placeholder="e.g. Good, or note any damage" {...register("condition")} />
      <LocationField enabled={useLoc} onChange={setUseLoc} status={geo.status} />
      {errors.root && <p role="alert" className="font-semibold text-red-700">{errors.root.message}</p>}
      <button className="btn btn-primary w-full" disabled={isSubmitting}>Check in</button>
    </form>
  );
}

export default function ToolDetail() {
  const { id = "" } = useParams();
  const companyId = useSession((s) => s.companyId) ?? "";
  const [sheet, setSheet] = useState<"out" | "in" | null>(null);
  const [adding, setAdding] = useState(false);
  const [newWorkerId, setNewWorkerId] = useState<string>();

  const data = useLiveQuery(async () => ({
    tool: (await db.tools.get(id)) ?? null,
    open: (await db.checkouts.where("tool_id").equals(id).filter((c) => c.checked_in_at === null).first()) ?? null,
    workers: await db.workers.where("company_id").equals(companyId).sortBy("name"),
    history: (await db.checkouts.where("tool_id").equals(id).sortBy("checked_out_at")).reverse(),
  }), [id, companyId]);

  if (!data) return <Skeleton className="h-72" />;
  const { tool, open, workers, history } = data;
  if (!tool || tool.company_id !== companyId) {
    return <EmptyState title="Tool not found" body="It may not have synced to this device yet."
      action={<Link to="/" className="btn btn-ghost">Back to tools</Link>} />;
  }
  const holder = workers.find((w) => w.id === open?.worker_id);
  const close = () => { setSheet(null); setAdding(false); };

  return (
    <div className="space-y-4">
      {tool.photo_url && <img src={tool.photo_url} alt={tool.name} className="h-48 w-full rounded-lg object-cover" />}
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-mono text-stone-600">{tool.tool_code}</p>
          <h1 className="text-2xl font-extrabold">{tool.name}</h1>
          {tool.category && <p className="text-stone-700">{tool.category}</p>}
        </div>
        <StatusBadge status={tool.status} />
      </div>
      {tool._error && <p role="alert" className="card border-red-700 font-semibold text-red-700">Not saved to the cloud: {tool._error}</p>}
      {open && (
        <p className="card font-semibold">
          With {holder?.name ?? "a worker"} since {new Date(open.checked_out_at).toLocaleDateString("en-ZA")}
          {open.due_at && `, due ${new Date(open.due_at).toLocaleDateString("en-ZA")}`}
        </p>
      )}
      {tool.status === "available" && <button className="btn btn-primary w-full" onClick={() => setSheet("out")}>Check out</button>}
      {tool.status === "checked_out" && <button className="btn btn-primary w-full" onClick={() => setSheet("in")}>Check in</button>}

      <div className="card flex flex-col items-center gap-3">
        <div id="qr-label" className="flex flex-col items-center gap-1 bg-white p-3">
          <QRCodeSVG value={`${window.location.origin}/tool/${tool.id}`} size={176} level="M" />
          <p className="font-mono text-lg font-bold">{tool.tool_code}</p>
          <p className="text-sm">{tool.name}</p>
        </div>
        <button className="btn btn-ghost w-full" onClick={() => window.print()}>Print QR label</button>
      </div>

      <HistoryList checkouts={history} workers={workers} />

      <ReportButtons toolId={tool.id} />

      <Modal open={sheet === "out"} title={adding ? "New worker" : "Check out"} onClose={close}>
        {adding
          ? <NewWorkerForm onCreated={(w) => { setNewWorkerId(w.id); setAdding(false); }} />
          : <CheckOutForm key={newWorkerId ?? "none"} toolId={tool.id} workers={workers.filter((w) => w.active)}
              defaultWorkerId={newWorkerId} onAdd={() => setAdding(true)} onDone={close} />}
      </Modal>
      <Modal open={sheet === "in"} title="Check in" onClose={close}>
        <CheckInForm toolId={tool.id} onDone={close} />
      </Modal>
    </div>
  );
}
