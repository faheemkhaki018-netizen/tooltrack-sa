import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Html5Qrcode } from "html5-qrcode";
import { db } from "../lib/db";
import { useSession } from "../store/session";

export default function Scanner() {
  const nav = useNavigate();
  const companyId = useSession((s) => s.companyId) ?? "";
  const [cameraError, setCameraError] = useState(false);
  const [code, setCode] = useState("");
  const [lookupError, setLookupError] = useState<string | null>(null);

  useEffect(() => {
    const scanner = new Html5Qrcode("qr-reader");
    let handled = false;
    const starting = scanner.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: 240 },
      (text) => {
        const id = /\/tool\/([0-9a-f-]{36})/i.exec(text)?.[1];
        if (id && !handled) { handled = true; nav(`/tool/${id}`); }
      },
      () => undefined, // per-frame "no QR found" noise
    );
    starting.catch(() => setCameraError(true)); // permission denied / no camera: fall back to manual entry
    return () => { // wait for start to settle so the camera is always released
      starting.then(() => scanner.stop()).then(() => scanner.clear()).catch(() => undefined);
    };
  }, [nav]);

  const lookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const wanted = code.trim().toUpperCase();
    const tool = await db.tools.where("company_id").equals(companyId).filter((t) => t.tool_code === wanted).first();
    if (tool) nav(`/tool/${tool.id}`);
    else setLookupError(`No tool with code ${wanted || "(empty)"}. Check the label and try again.`);
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Scan a tool</h1>
      {cameraError
        ? <p role="alert" className="card font-semibold">The camera isn't available. Allow camera access in your browser settings, or type the code below.</p>
        : <div id="qr-reader" className="overflow-hidden rounded-lg border-2 border-stone-900" />}
      <form onSubmit={(e) => void lookup(e)} className="space-y-2">
        <label className="block text-base font-semibold">
          Or type the code on the label
          <input className="input font-mono uppercase" placeholder="TT-0001" value={code}
            onChange={(e) => { setCode(e.target.value); setLookupError(null); }} />
        </label>
        {lookupError && <p role="alert" className="font-semibold text-red-700">{lookupError}</p>}
        <button className="btn btn-ghost w-full">Find tool</button>
      </form>
    </div>
  );
}
