import { useState } from "react";
import { Link } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { EmptyState, Skeleton, StatusBadge } from "../components/ui";
import { db } from "../lib/db";
import { useSession } from "../store/session";

export default function Dashboard() {
  const companyId = useSession((s) => s.companyId) ?? "";
  const tools = useLiveQuery(() => db.tools.where("company_id").equals(companyId).sortBy("tool_code"), [companyId]);
  const [q, setQ] = useState("");

  if (!tools) return <div className="space-y-3"><Skeleton className="h-12" /><Skeleton className="h-20" /><Skeleton className="h-20" /></div>;
  if (tools.length === 0) {
    return <EmptyState title="No tools yet" body="Register your first tool, print its QR label and stick it on."
      action={<Link to="/add" className="btn btn-primary">Add your first tool</Link>} />;
  }

  const term = q.trim().toLowerCase();
  const shown = tools.filter((t) => !term || `${t.tool_code} ${t.name} ${t.category ?? ""}`.toLowerCase().includes(term));
  const out = tools.filter((t) => t.status === "checked_out").length;

  return (
    <div className="space-y-3">
      <p className="text-lg font-bold">{out} of {tools.length} tools checked out</p>
      <input className="input" type="search" placeholder="Search by code, name or category" aria-label="Search tools"
        value={q} onChange={(e) => setQ(e.target.value)} />
      {shown.length === 0 && <p className="text-stone-700">No tools match “{q}”.</p>}
      <ul className="space-y-2">
        {shown.map((t) => (
          <li key={t.id}>
            <Link to={`/tool/${t.id}`} className="card flex items-center gap-3 hover:border-stone-900">
              {t.photo_url
                ? <img src={t.photo_url} alt="" className="h-14 w-14 rounded object-cover" />
                : <div className="h-14 w-14 rounded bg-stone-200" aria-hidden="true" />}
              <div className="min-w-0 flex-1">
                <p className="font-mono text-sm text-stone-600">{t.tool_code}</p>
                <p className="truncate text-lg font-bold">{t.name}</p>
                {t._error && <p className="text-sm font-semibold text-red-700">Not accepted by the server</p>}
              </div>
              <StatusBadge status={t.status} />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
