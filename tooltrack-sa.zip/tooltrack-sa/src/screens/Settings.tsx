import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "../lib/db";
import { supabase } from "../lib/supabase";
import { useSession } from "../store/session";
import ReportButtons from "../components/ReportButtons";
import { useSync } from "../store/syncStore";

const PLANS = [
  { id: "crew", label: "Crew", price: "R149 a month" },
  { id: "business", label: "Business", price: "R399 a month" },
] as const;

// PayFast needs a real form POST from the browser; the fields are already signed by the server.
function postToPayFast(action: string, fields: [string, string][]) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = action;
  for (const [name, value] of fields) {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = name;
    input.value = value;
    form.appendChild(input);
  }
  document.body.appendChild(form);
  form.submit();
}

export default function Settings() {
  const mode = useSession((s) => s.mode);
  const signOut = useSession((s) => s.signOut);
  const { status, pending, rejected, lastSyncedAt, error, syncNow } = useSync();
  const company = useLiveQuery(() => db.meta.get("company"))?.value as { name: string; plan: string } | undefined;
  const [params] = useSearchParams();
  const [payError, setPayError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const plan = company?.plan ?? "free";

  const upgrade = async (id: string) => {
    setPayError(null);
    if (!navigator.onLine) return setPayError("You need a connection to upgrade. Try again when you're online.");
    setBusy(true);
    const { data, error: fnError } = await supabase!.functions.invoke("payfast-checkout", { body: { plan: id } });
    if (fnError || !data?.action) { setBusy(false); return setPayError("Couldn't start checkout. Please try again."); }
    postToPayFast(data.action as string, data.fields as [string, string][]);
  };

  const logout = async () => {
    try { await signOut(); } catch (e) {
      if (e instanceof Error && e.message === "UNSYNCED" &&
        window.confirm("Some changes haven't synced yet and will be lost. Sign out anyway?")) await signOut(true);
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Settings</h1>
      {params.get("upgrade") === "success" && <p role="status" className="card font-semibold text-emerald-800">Payment received. Your plan updates within a minute.</p>}
      {params.get("upgrade") === "cancelled" && <p role="status" className="card font-semibold">Upgrade cancelled. You haven't been charged.</p>}

      <section className="card space-y-2">
        <h2 className="text-lg font-extrabold">Sync</h2>
        {mode === "demo"
          ? <p>Demo mode keeps everything on this device. Sign out and create a business account to back up and share.</p>
          : <>
              <p>{status === "offline" ? "Offline. Changes are saved here and will upload when you're back online." : `${pending} waiting to upload.`}</p>
              {rejected > 0 && <p role="alert" className="font-semibold text-red-700">{rejected} change(s) were refused by the server, usually a duplicate tool code.</p>}
              {error && <p role="alert" className="font-semibold text-red-700">{error}</p>}
              {lastSyncedAt && <p className="text-sm text-stone-600">Last synced {new Date(lastSyncedAt).toLocaleTimeString("en-ZA")}</p>}
              <button className="btn btn-ghost w-full" onClick={() => void syncNow()} disabled={status === "syncing"}>
                {status === "syncing" ? "Syncing…" : "Sync now"}
              </button>
            </>}
      </section>

      {mode === "cloud" && (
        <section className="card space-y-2">
          <h2 className="text-lg font-extrabold">Plan: {plan === "free" ? "Free" : plan === "crew" ? "Crew" : "Business"}</h2>
          {payError && <p role="alert" className="font-semibold text-red-700">{payError}</p>}
          {PLANS.filter((p) => p.id !== plan && !(plan === "business")).map((p) => (
            <button key={p.id} className="btn btn-primary w-full" disabled={busy} onClick={() => void upgrade(p.id)}>
              Upgrade to {p.label}, {p.price}
            </button>
          ))}
        </section>
      )}

      <ReportButtons />

      <button className="btn btn-ghost w-full" onClick={() => void logout()}>{mode === "demo" ? "Leave demo mode" : "Sign out"}</button>
    </div>
  );
}
