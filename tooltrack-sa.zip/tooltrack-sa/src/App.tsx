import { useEffect } from "react";
import { BrowserRouter, Navigate, NavLink, Outlet, Route, Routes } from "react-router-dom";
import ErrorBoundary from "./components/ErrorBoundary";
import { Logo, Skeleton } from "./components/ui";
import AddTool from "./screens/AddTool";
import Auth from "./screens/Auth";
import Dashboard from "./screens/Dashboard";
import Scanner from "./screens/Scanner";
import Settings from "./screens/Settings";
import ToolDetail from "./screens/ToolDetail";
import { useSession } from "./store/session";
import { startSyncTriggers, useSync } from "./store/syncStore";

function SyncChip() {
  const mode = useSession((s) => s.mode);
  const { status, pending, rejected } = useSync();
  let text = "Synced";
  if (mode === "demo") text = "Demo mode";
  else if (status === "syncing") text = "Syncing…";
  else if (status === "offline") text = pending ? `Offline, ${pending} waiting` : "Offline";
  else if (rejected) text = `${rejected} not accepted`;
  else if (pending) text = `${pending} to sync`;
  return <span className="rounded bg-stone-900 px-2 py-1 text-sm font-semibold text-brand" role="status">{text}</span>;
}

const NAV = [["/", "Tools"], ["/add", "Add tool"], ["/scan", "Scan"], ["/settings", "Settings"]] as const;

function Shell() {
  useEffect(() => startSyncTriggers(), []);
  return (
    <div className="mx-auto flex min-h-full max-w-md flex-col">
      <header className="sticky top-0 z-10 border-b border-stone-200 bg-white text-stone-900 pt-[env(safe-area-inset-top)]">
        <div className="flex items-center justify-between px-4 py-3">
          <Logo />
          <SyncChip />
        </div>
        <div className="hazard" />
      </header>
      <main className="flex-1 p-4 pb-28"><Outlet /></main>
      <nav className="fixed inset-x-0 bottom-0 z-10 border-t-2 border-stone-900 bg-white pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-md grid-cols-4">
          {NAV.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"}
              className={({ isActive }) => `py-4 text-center text-base font-bold ${isActive ? "bg-brand" : ""}`}>
              {label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  const ready = useSession((s) => s.ready);
  const mode = useSession((s) => s.mode);
  const init = useSession((s) => s.init);
  useEffect(() => { void init(); }, [init]);

  if (!ready) return <div className="p-6"><Skeleton className="h-24" /></div>;
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          {mode ? (
            <Route element={<Shell />}>
              <Route index element={<Dashboard />} />
              <Route path="add" element={<AddTool />} />
              <Route path="scan" element={<Scanner />} />
              <Route path="tool/:id" element={<ToolDetail />} />
              <Route path="settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          ) : (
            <Route path="*" element={<Auth />} />
          )}
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
