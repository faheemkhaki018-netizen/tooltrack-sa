// Sharing helpers. On phones the Web Share API hands the PDF straight to WhatsApp;
// elsewhere we download it and open a WhatsApp chat with a text summary.
export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

/** wa.me link. Local SA numbers (082 123 4567) become 27821234567; no phone opens WhatsApp's chat picker. */
export function whatsappLink(phone: string | null, text: string) {
  const digits = (phone ?? "").replace(/\D/g, "");
  const intl = digits.startsWith("00") ? digits.slice(2) : digits.startsWith("0") ? `27${digits.slice(1)}` : digits;
  return `https://wa.me/${intl}?text=${encodeURIComponent(text)}`;
}

export type ShareResult = "shared" | "cancelled" | "fallback";

export async function sharePdf(blob: Blob, filename: string, text: string): Promise<ShareResult> {
  const file = new File([blob], filename, { type: "application/pdf" });
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: filename, text });
      return "shared";
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return "cancelled";
      // any other failure: fall through to download + WhatsApp link
    }
  }
  downloadBlob(blob, filename);
  window.open(whatsappLink(null, text), "_blank", "noopener");
  return "fallback";
}
