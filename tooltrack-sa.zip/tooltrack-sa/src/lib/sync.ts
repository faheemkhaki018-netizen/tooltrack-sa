// Sync engine: push dirty rows (parents first), then pull server changes.
// Strategy: last-write-wins. The server trigger stamps updated_at, and a row with unpushed local
// edits is never overwritten by a pull, so the most recent *push* wins.
import type { Table } from "dexie";
import { DEMO_COMPANY, db, getMeta, setMeta, type Row, type Tool } from "./db";
import { supabase } from "./supabase";

type TableName = "workers" | "tools" | "checkouts";
const ORDER: TableName[] = ["workers", "tools", "checkouts"]; // FK order
const PAGE = 500;
const OVERLAP_MS = 5000; // re-read a small window so a slow-committing transaction can't be missed

export class NetworkError extends Error {}
type Failure = Error & { code?: string; status?: number };

const fail = (e: { message: string; code?: string; status?: number }, status?: number): Failure =>
  Object.assign(new Error(e.message), { code: e.code, status: e.status ?? status });

// Transient = worth retrying later. Anything else (RLS, unique, FK) is a permanent rejection of that row.
const isTransient = (e: Failure) =>
  !navigator.onLine || e.status === 0 || e.status === 401 || e.status === 429 || (e.status ?? 0) >= 500 ||
  (!e.code && /fetch|network|load failed/i.test(e.message));

const strip = (r: object) => Object.fromEntries(Object.entries(r).filter(([k]) => !k.startsWith("_")));
const tbl = (n: TableName) => db.table(n) as Table<Row, string>;
const isSyncable = (r: Row) => r.company_id !== DEMO_COMPANY;

async function uploadPhoto(tool: Tool): Promise<string> {
  const sb = supabase!;
  const blob = await (await fetch(tool.photo_url!)).blob(); // data: URLs resolve offline
  const path = `${tool.company_id}/${tool.id}.jpg`;
  const { error } = await sb.storage.from("tool-photos").upload(path, blob, {
    upsert: true,
    contentType: blob.type || "image/jpeg",
  });
  if (error) throw fail(error as { message: string; status?: number });
  return `${sb.storage.from("tool-photos").getPublicUrl(path).data.publicUrl}?v=${Date.now()}`;
}

async function pushTable(name: TableName) {
  const table = tbl(name);
  const dirty = await table.where("_dirty").equals(1).filter((r) => isSyncable(r) && !r._error).toArray();
  for (const row of dirty) {
    try {
      let out: Row = row;
      if (name === "tools" && (row as Tool).photo_url?.startsWith("data:")) {
        out = { ...(row as Tool), photo_url: await uploadPhoto(row as Tool) }; // swap data: URL -> public URL
      }
      const { data, error, status } = await supabase!.from(name).upsert(strip(out), { onConflict: "id" }).select("updated_at").single();
      if (error) throw fail(error, status);

      await db.transaction("rw", table, async () => {
        const cur = await table.get(row.id);
        if (!cur) return;
        const next = { ...cur, updated_at: data.updated_at as string } as Row;
        if (name === "tools" && (cur as Tool).photo_url === (row as Tool).photo_url) (next as Tool).photo_url = (out as Tool).photo_url;
        if (cur._rev === row._rev) next._dirty = 0; // untouched during the push -> clean
        await table.put(next);
      });
    } catch (e) {
      const f = e as Failure;
      if (isTransient(f)) throw new NetworkError(f.message); // stop; retry later with backoff
      await table.update(row.id, { _error: f.message }); // quarantine this row, keep syncing the rest
    }
  }
}

async function pullTable(name: TableName) {
  const table = tbl(name);
  const key = `cursor:${name}`;
  const cursor = (await getMeta<string>(key)) ?? "1970-01-01T00:00:00Z";
  const since = new Date(new Date(cursor).getTime() - OVERLAP_MS).toISOString();
  let max = cursor;

  for (let from = 0; ; from += PAGE) {
    const { data, error, status } = await supabase!.from(name).select("*").gt("updated_at", since)
      .order("updated_at").order("id").range(from, from + PAGE - 1);
    if (error) throw fail(error, status);
    const remote = (data ?? []) as Row[];

    await db.transaction("rw", table, async () => {
      const locals = await table.bulkGet(remote.map((r) => r.id));
      const merged = remote.flatMap((r, i) => (locals[i]?._dirty ? [] : [{ ...r, _dirty: 0 as const, _rev: locals[i]?._rev ?? 0 }]));
      await table.bulkPut(merged);
    });
    for (const r of remote) if (r.updated_at > max) max = r.updated_at;
    if (remote.length < PAGE) break;
  }
  await setMeta(key, max);
}

/** Runs one full sync. Throws NetworkError when offline/flaky so the caller can back off. */
export async function runSync(): Promise<void> {
  if (!supabase || (await getMeta<string>("mode")) !== "cloud") return; // demo mode: IndexedDB only
  if (!navigator.onLine) throw new NetworkError("offline");
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new NetworkError("no active session");
  try {
    for (const t of ORDER) await pushTable(t);
    for (const t of ORDER) await pullTable(t);
    const { data } = await supabase.from("companies").select("id, name, plan").single();
    if (data) await setMeta("company", data); // Settings reads the current plan from here
  } catch (e) {
    if (e instanceof NetworkError) throw e;
    const f = e as Failure;
    throw isTransient(f) ? new NetworkError(f.message) : e;
  }
}

/** pending = waiting to sync; rejected = server refused (needs the user's attention). */
export async function countPending() {
  let pending = 0, rejected = 0;
  for (const t of ORDER) {
    const rows = await tbl(t).where("_dirty").equals(1).filter(isSyncable).toArray();
    for (const r of rows) r._error ? rejected++ : pending++;
  }
  return { pending, rejected };
}
