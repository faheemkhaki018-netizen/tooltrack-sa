// Offline-first data access: every write is a local Dexie transaction, then a background sync is requested.
import { db, getMeta, type Checkout, type Tool, type Worker } from "./db";
import type { GeoResult } from "./geo";
import { requestSync } from "../store/syncStore";

const nowIso = () => new Date().toISOString();
const newRow = () => ({ _dirty: 1 as const, _rev: 1, created_at: nowIso(), updated_at: nowIso() });
const touch = <T extends { _rev: number }>(r: T) => ({ ...r, _dirty: 1 as const, _rev: r._rev + 1, updated_at: nowIso() });

async function companyId() {
  const id = await getMeta<string>("companyId");
  if (!id) throw new Error("Not signed in");
  return id;
}

export interface NewTool { name: string; category?: string; serial_number?: string; photo_url?: string; notes?: string }

export async function createTool(input: NewTool): Promise<Tool> {
  const company_id = await companyId();
  const tool = await db.transaction("rw", db.tools, async () => {
    const existing = await db.tools.where("company_id").equals(company_id).toArray();
    const max = existing.reduce((m, t) => Math.max(m, Number(/(\d+)$/.exec(t.tool_code)?.[1] ?? 0)), 0);
    const row: Tool = {
      id: crypto.randomUUID(), // client-generated: no ID remapping on sync
      company_id,
      tool_code: `TT-${String(max + 1).padStart(4, "0")}`,
      name: input.name,
      category: input.category ?? null,
      serial_number: input.serial_number ?? null,
      photo_url: input.photo_url ?? null,
      notes: input.notes ?? null,
      status: "available",
      ...newRow(),
    };
    await db.tools.add(row);
    return row;
  });
  requestSync();
  return tool;
}

export async function createWorker(input: { name: string; phone?: string }): Promise<Worker> {
  const row: Worker = {
    id: crypto.randomUUID(), company_id: await companyId(), name: input.name,
    phone: input.phone ?? null, active: true, ...newRow(),
  };
  await db.workers.add(row);
  requestSync();
  return row;
}

export async function checkOut(toolId: string, workerId: string, opts: { dueAt?: string; condition?: string; location?: GeoResult | null } = {}): Promise<Checkout> {
  const company_id = await companyId();
  const row = await db.transaction("rw", db.tools, db.checkouts, async () => {
    const tool = await db.tools.get(toolId);
    if (!tool || tool.company_id !== company_id) throw new Error("Tool not found");
    if (tool.status !== "available") throw new Error(`Tool is ${tool.status.replace("_", " ")}`);
    const c: Checkout = {
      id: crypto.randomUUID(), company_id, tool_id: toolId, worker_id: workerId,
      checked_out_at: nowIso(), due_at: opts.dueAt ?? null, checked_in_at: null,
      condition_out: opts.condition ?? null, condition_in: null, notes: null,
      latitude: opts.location?.latitude ?? null, longitude: opts.location?.longitude ?? null, location_accuracy: opts.location?.accuracy ?? null,
      ...newRow(),
    };
    await db.checkouts.add(c);
    await db.tools.put(touch({ ...tool, status: "checked_out" as const }));
    return c;
  });
  requestSync();
  return row;
}

export async function checkIn(toolId: string, opts: { condition?: string; location?: GeoResult | null } = {}): Promise<void> {
  await db.transaction("rw", db.tools, db.checkouts, async () => {
    const tool = await db.tools.get(toolId);
    const open = await db.checkouts.where("tool_id").equals(toolId).filter((c) => c.checked_in_at === null).first();
    if (!tool || !open) throw new Error("Tool is not checked out");
    await db.checkouts.put(touch({
      ...open, checked_in_at: nowIso(), condition_in: opts.condition ?? null,
      in_latitude: opts.location?.latitude ?? null, in_longitude: opts.location?.longitude ?? null, in_location_accuracy: opts.location?.accuracy ?? null,
    }));
    await db.tools.put(touch({ ...tool, status: "available" as const }));
  });
  requestSync();
}
