// Local IndexedDB (Dexie). Every read/write in the UI goes here first; sync happens in the background.
import Dexie, { type Table } from "dexie";

export const DEMO_COMPANY = "demo"; // rows with this company_id are never synced

export type ToolStatus = "available" | "checked_out" | "maintenance" | "lost";

interface SyncFields {
  _dirty: 0 | 1;   // 1 = local changes not yet on the server (numbers are indexable, booleans aren't)
  _rev: number;    // bumped on every local write so push can detect edits made mid-sync
  _error?: string; // set when the server permanently rejected the row (e.g. duplicate tool_code)
}
interface Base extends SyncFields {
  id: string;
  company_id: string;
  created_at: string;
  updated_at: string;
}
export interface Tool extends Base {
  tool_code: string;
  name: string;
  category: string | null;
  serial_number: string | null;
  photo_url: string | null; // data: URL while offline, public URL after sync
  status: ToolStatus;
  notes: string | null;
}
export interface Worker extends Base {
  name: string;
  phone: string | null;
  active: boolean;
}
export interface Checkout extends Base {
  tool_id: string;
  worker_id: string;
  checked_out_at: string;
  due_at: string | null;
  checked_in_at: string | null;
  condition_out: string | null;
  condition_in: string | null;
  notes: string | null;
  // GPS: where it went out (latitude...) and where it came back (in_*). All optional; GPS can fail.
  latitude?: number | null;
  longitude?: number | null;
  location_accuracy?: number | null;
  in_latitude?: number | null;
  in_longitude?: number | null;
  in_location_accuracy?: number | null;
}
export type Row = Tool | Worker | Checkout;

const GPS_FIELDS = ["latitude", "longitude", "location_accuracy", "in_latitude", "in_longitude", "in_location_accuracy"] as const;

class ToolTrackDB extends Dexie {
  tools!: Table<Tool, string>;
  workers!: Table<Worker, string>;
  checkouts!: Table<Checkout, string>;
  meta!: Table<{ key: string; value: unknown }, string>;

  constructor() {
    super("tooltrack");
    this.version(1).stores({
      tools: "id, company_id, tool_code, status, _dirty, updated_at",
      workers: "id, company_id, _dirty, updated_at",
      checkouts: "id, company_id, tool_id, worker_id, _dirty, updated_at",
      meta: "key",
    });
    // v2: GPS fields on checkouts. They are not indexed, so no index changes; the bump backfills nulls
    // on existing rows so every stored checkout has the same shape.
    this.version(2).stores({}).upgrade((tx) =>
      tx.table("checkouts").toCollection().modify((c: Record<string, unknown>) => {
        for (const k of GPS_FIELDS) if (c[k] === undefined) c[k] = null;
      }),
    );
  }
}

export const db = new ToolTrackDB();
export const getMeta = async <T>(key: string) => (await db.meta.get(key))?.value as T | undefined;
export const setMeta = (key: string, value: unknown) => db.meta.put({ key, value });
