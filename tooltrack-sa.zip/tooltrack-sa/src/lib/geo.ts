// One-shot GPS lookup for check-out / check-in. Never watchPosition: we only ask when the user acts.
import { useCallback, useState } from "react";

export type GeoErrorCode = "PERMISSION_DENIED" | "POSITION_UNAVAILABLE" | "TIMEOUT" | "UNSUPPORTED";
export interface GeoResult {
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null; // metres
  error: GeoErrorCode | null;
}

const NONE = { latitude: null, longitude: null, accuracy: null } as const;

/** Always resolves (never rejects), so a GPS failure can never block a checkout. */
export function getCurrentLocation(timeoutMs = 5000): Promise<GeoResult> {
  return new Promise((resolve) => {
    let done = false;
    let guard: ReturnType<typeof setTimeout> | undefined;
    const finish = (r: GeoResult) => {
      if (done) return;
      done = true;
      clearTimeout(guard);
      if (r.error) console.warn(`Location unavailable: ${r.error}`);
      resolve(r);
    };
    if (!("geolocation" in navigator)) return finish({ ...NONE, error: "UNSUPPORTED" });

    // Some browsers don't count the permission prompt against `timeout`, so a person who ignores
    // the prompt could hang the checkout forever. This backstop guarantees it always moves on.
    guard = setTimeout(() => finish({ ...NONE, error: "TIMEOUT" }), timeoutMs + 1000);

    navigator.geolocation.getCurrentPosition(
      (p) => finish({ latitude: p.coords.latitude, longitude: p.coords.longitude, accuracy: p.coords.accuracy, error: null }),
      (e) => finish({
        ...NONE,
        error: e.code === e.PERMISSION_DENIED ? "PERMISSION_DENIED" : e.code === e.TIMEOUT ? "TIMEOUT" : "POSITION_UNAVAILABLE",
      }),
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30_000 },
    );
  });
}

export type LocationStatus = "idle" | "locating" | "captured" | "unavailable";

/** Drives the "Locating... / captured / unavailable" indicator around a single lookup. */
export function useLocationCapture() {
  const [status, setStatus] = useState<LocationStatus>("idle");
  const locate = useCallback(async (enabled: boolean): Promise<GeoResult | null> => {
    if (!enabled) return null; // the person switched location off for this action
    setStatus("locating");
    const result = await getCurrentLocation();
    setStatus(result.error ? "unavailable" : "captured");
    await new Promise((r) => setTimeout(r, 700)); // let them read the result before the modal closes
    return result;
  }, []);
  return { status, locate };
}
