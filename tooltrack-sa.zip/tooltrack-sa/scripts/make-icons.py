"""Builds the PWA icons in public/ from public/logo-mark.png (needs Pillow: pip install pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw

PUB = Path(__file__).resolve().parent.parent / "public"
mark = Image.open(PUB / "logo-mark.png").convert("RGBA")

def icon(size: int, rounded: bool, fill: float) -> Image.Image:
    big = size * 4  # draw large, then downscale for smooth edges
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0) if rounded else (255, 255, 255, 255))
    if rounded:
        ImageDraw.Draw(img).rounded_rectangle((0, 0, big - 1, big - 1), radius=int(big * 0.22),
                                              fill=(255, 255, 255, 255), outline=(214, 211, 209, 255), width=max(2, big // 100))
    m = mark.copy(); m.thumbnail((int(big * fill),) * 2, Image.LANCZOS)
    img.alpha_composite(m, ((big - m.width) // 2, (big - m.height) // 2))
    return img.resize((size, size), Image.LANCZOS)

icon(192, True, 0.74).save(PUB / "icon-192.png")
icon(512, True, 0.74).save(PUB / "icon-512.png")
icon(512, False, 0.56).save(PUB / "maskable-512.png")  # full-bleed; logo kept inside the 80% safe zone
icon(64, True, 0.8).save(PUB / "favicon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])
print("icons written")
