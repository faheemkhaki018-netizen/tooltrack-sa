-- 002_add_gps_to_checkouts.sql
-- Where a tool was signed out (latitude/longitude/location_accuracy) and where it came back (in_*).
-- Everything is nullable: location is optional and GPS can fail, so a checkout must never depend on it.
-- Accuracy is the radius in metres reported by the device.

alter table public.checkouts
  add column latitude            float8,
  add column longitude           float8,
  add column location_accuracy   float8,
  add column in_latitude         float8,
  add column in_longitude        float8,
  add column in_location_accuracy float8;

alter table public.checkouts
  add constraint checkouts_gps_valid check (
    (latitude  is null or latitude  between -90  and 90)  and
    (longitude is null or longitude between -180 and 180) and
    (in_latitude  is null or in_latitude  between -90  and 90)  and
    (in_longitude is null or in_longitude between -180 and 180) and
    (location_accuracy is null or location_accuracy >= 0) and
    (in_location_accuracy is null or in_location_accuracy >= 0) and
    ((latitude is null) = (longitude is null)) and
    ((in_latitude is null) = (in_longitude is null))
  );

comment on column public.checkouts.latitude is
  'Captured only when the user opts in at check-out; for tool audit purposes only (POPIA).';

-- RLS: no change needed. "checkouts: company only" is FOR ALL scoped by company_id and covers new columns,
-- and checkouts has no column-level grants that would exclude them.
