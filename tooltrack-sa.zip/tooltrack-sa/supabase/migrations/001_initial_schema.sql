-- ToolTrack SA — 001_initial_schema.sql
-- Client-generated UUIDs are accepted on every table (defaults only apply if omitted).
-- updated_at is set by a server trigger, so the server clock decides last-write-wins.

create table public.companies (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  plan          text not null default 'free' check (plan in ('free', 'crew', 'business')),
  payfast_token text,                                  -- PayFast subscription token
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade,
  full_name  text,
  role       text not null default 'owner' check (role in ('owner', 'member')),
  created_at timestamptz not null default now()
);

create table public.workers (
  id         uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name       text not null,
  phone      text,
  active     boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, company_id)                               -- target for composite FK below
);

create table public.tools (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references public.companies(id) on delete cascade,
  tool_code     text not null,                          -- e.g. TT-0001
  name          text not null,
  category      text,
  serial_number text,
  photo_url     text,                                   -- public URL after sync (data: URL while offline)
  status        text not null default 'available'
                check (status in ('available', 'checked_out', 'maintenance', 'lost')),
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (company_id, tool_code),                       -- two companies can both own TT-0001
  unique (id, company_id)
);

create table public.checkouts (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references public.companies(id) on delete cascade,  -- denormalized for RLS + sync
  tool_id        uuid not null,
  worker_id      uuid not null,
  checked_out_at timestamptz not null default now(),
  due_at         timestamptz,
  checked_in_at  timestamptz,
  condition_out  text,
  condition_in   text,
  notes          text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  -- Composite FKs: a checkout can only reference tools/workers of its own company.
  foreign key (tool_id, company_id)   references public.tools(id, company_id)   on delete cascade,
  foreign key (worker_id, company_id) references public.workers(id, company_id) on delete restrict
);

-- Per-company delta pulls: "give me rows updated since X".
create index tools_sync_idx      on public.tools (company_id, updated_at);
create index workers_sync_idx    on public.workers (company_id, updated_at);
create index checkouts_sync_idx  on public.checkouts (company_id, updated_at);
create index checkouts_open_idx  on public.checkouts (tool_id) where checked_in_at is null;

-- Server-authoritative updated_at (last-write-wins).
create function public.set_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger companies_updated_at before insert or update on public.companies for each row execute function public.set_updated_at();
create trigger workers_updated_at   before insert or update on public.workers   for each row execute function public.set_updated_at();
create trigger tools_updated_at     before insert or update on public.tools     for each row execute function public.set_updated_at();
create trigger checkouts_updated_at before insert or update on public.checkouts for each row execute function public.set_updated_at();

-- Current user's company (SECURITY DEFINER avoids RLS recursion on profiles).
create function public.current_company_id() returns uuid
language sql stable security definer set search_path = public as $$
  select company_id from public.profiles where id = auth.uid()
$$;

-- Called once after sign-up: creates the company and the owner's profile.
create function public.register_company(p_company_name text, p_full_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_company uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  select company_id into v_company from public.profiles where id = auth.uid();
  if v_company is not null then return v_company; end if;   -- idempotent
  insert into public.companies (name) values (p_company_name) returning id into v_company;
  insert into public.profiles (id, company_id, full_name) values (auth.uid(), v_company, p_full_name);
  return v_company;
end $$;

revoke all on function public.register_company(text, text) from public;
grant execute on function public.register_company(text, text) to authenticated;
grant execute on function public.current_company_id() to authenticated;

-- Row Level Security
alter table public.companies enable row level security;
alter table public.profiles  enable row level security;
alter table public.workers   enable row level security;
alter table public.tools     enable row level security;
alter table public.checkouts enable row level security;

create policy "own company: read"   on public.companies for select to authenticated using (id = public.current_company_id());
create policy "own company: rename" on public.companies for update to authenticated using (id = public.current_company_id());
-- Users must never be able to upgrade themselves: only the webhook (service role) writes plan/payfast_token.
revoke update on public.companies from authenticated;
grant  update (name) on public.companies to authenticated;

create policy "profiles: read company" on public.profiles for select to authenticated using (company_id = public.current_company_id());
create policy "profiles: update self"  on public.profiles for update to authenticated using (id = auth.uid());
revoke update on public.profiles from authenticated;
grant  update (full_name) on public.profiles to authenticated;

create policy "workers: company only"   on public.workers   for all to authenticated
  using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());
create policy "tools: company only"     on public.tools     for all to authenticated
  using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());
create policy "checkouts: company only" on public.checkouts for all to authenticated
  using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

-- Storage: public bucket (URLs work in PDFs/WhatsApp); writes limited to {company_id}/... paths.
insert into storage.buckets (id, name, public) values ('tool-photos', 'tool-photos', true)
on conflict (id) do nothing;

create policy "tool-photos: company read"   on storage.objects for select to authenticated
  using (bucket_id = 'tool-photos' and (storage.foldername(name))[1] = public.current_company_id()::text);
create policy "tool-photos: company insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'tool-photos' and (storage.foldername(name))[1] = public.current_company_id()::text);
create policy "tool-photos: company update" on storage.objects for update to authenticated
  using (bucket_id = 'tool-photos' and (storage.foldername(name))[1] = public.current_company_id()::text);
create policy "tool-photos: company delete" on storage.objects for delete to authenticated
  using (bucket_id = 'tool-photos' and (storage.foldername(name))[1] = public.current_company_id()::text);
