// payfast-checkout — builds the signed PayFast payload server-side.
//
// Secrets (set once; never in the browser):
//   supabase secrets set PAYFAST_MERCHANT_ID=... PAYFAST_MERCHANT_KEY=... \
//     PAYFAST_PASSPHRASE=... PAYFAST_MODE=sandbox APP_URL=https://your-app.vercel.app
// Deploy:
//   supabase functions deploy payfast-checkout
//   supabase functions deploy payfast-webhook --no-verify-jwt   # PayFast can't send a Supabase JWT
import { createClient } from "npm:@supabase/supabase-js@2";
import { Entries, PLANS, PaidPlan, payfastUrls, signature } from "../_shared/payfast.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const env = (k: string) => Deno.env.get(k) ?? "";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    // Identify the caller from their JWT; RLS then scopes the profile lookup to them.
    const supabase = createClient(env("SUPABASE_URL"), env("SUPABASE_ANON_KEY"), {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return json({ error: "Not signed in" }, 401);

    const { plan } = await req.json();
    if (typeof plan !== "string" || !(plan in PLANS)) return json({ error: "Unknown plan" }, 400);
    const { amount, name } = PLANS[plan as PaidPlan];

    const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
    if (!profile) return json({ error: "No company for this user" }, 400);

    const app = env("APP_URL").replace(/\/$/, "");
    // Order follows PayFast's documented field order — it is part of the signature.
    const entries: Entries = [
      ["merchant_id", env("PAYFAST_MERCHANT_ID")],
      ["merchant_key", env("PAYFAST_MERCHANT_KEY")],
      ["return_url", `${app}/settings?upgrade=success`],
      ["cancel_url", `${app}/settings?upgrade=cancelled`],
      ["notify_url", `${env("SUPABASE_URL")}/functions/v1/payfast-webhook`],
      ["email_address", user.email ?? ""],
      ["m_payment_id", crypto.randomUUID()],
      ["amount", amount],
      ["item_name", name],
      ["custom_str1", plan],                     // plan to activate
      ["custom_str2", profile.company_id],       // company to upgrade
      ["subscription_type", "1"],
      ["recurring_amount", amount],
      ["frequency", "3"],                        // monthly
      ["cycles", "0"],                           // until cancelled
    ];
    entries.push(["signature", signature(entries, env("PAYFAST_PASSPHRASE"), true)]);

    // Client renders a hidden <form method="POST" action={action}> with these fields, in order.
    return json({ action: payfastUrls(env("PAYFAST_MODE")).process, fields: entries });
  } catch (e) {
    console.error("payfast-checkout failed", e);
    return json({ error: "Could not start checkout" }, 500);
  }
});
