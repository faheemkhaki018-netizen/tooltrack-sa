// Shared PayFast helpers (signature + URLs). Runs in Supabase Edge Functions (Deno).
import { createHash } from "node:crypto";

export type Entries = [string, string][];
export type PaidPlan = "crew" | "business";

// Server-side source of truth for prices — never trust an amount from the browser.
export const PLANS: Record<PaidPlan, { amount: string; name: string }> = {
  crew: { amount: "149.00", name: "ToolTrack SA Crew" },
  business: { amount: "399.00", name: "ToolTrack SA Business" },
};

export const payfastUrls = (mode: string) => {
  const host = mode === "live" ? "www.payfast.co.za" : "sandbox.payfast.co.za";
  return { process: `https://${host}/eng/process`, validate: `https://${host}/eng/query/validate` };
};

// PayFast signs against PHP-style urlencode(): spaces as "+", uppercase hex, and !'()*~ escaped.
const enc = (v: string) =>
  encodeURIComponent(v.trim())
    .replace(/[!'()*~]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase())
    .replace(/%20/g, "+");

// Field order matters. Checkout signatures skip empty values; ITN (webhook) signatures do not.
export const paramString = (entries: Entries, skipEmpty: boolean) =>
  entries
    .filter(([, v]) => !skipEmpty || v.trim() !== "")
    .map(([k, v]) => `${k}=${enc(v)}`)
    .join("&");

export const signature = (entries: Entries, passphrase: string, skipEmpty: boolean) => {
  const base = paramString(entries, skipEmpty);
  return createHash("md5").update(passphrase ? `${base}&passphrase=${enc(passphrase)}` : base).digest("hex");
};
