// payfast-webhook — PayFast ITN handler. Deploy with --no-verify-jwt.
// Trust nothing until: (1) signature matches, (2) PayFast confirms the payload as VALID,
// (3) merchant + amount match what we expect. Only then does the service role touch the DB.
import { createClient } from "npm:@supabase/supabase-js@2";
import { Entries, PLANS, PaidPlan, paramString, payfastUrls, signature } from "../_shared/payfast.ts";

const env = (k: string) => Deno.env.get(k) ?? "";
const reply = (msg: string, status: number) => new Response(msg, { status });

Deno.serve(async (req) => {
  if (req.method !== "POST") return reply("Method not allowed", 405);
  try {
    const params = new URLSearchParams(await req.text());
    const entries = [...params.entries()].filter(([k]) => k !== "signature") as Entries;

    // 1. Signature (posted field order, empty values included).
    if (signature(entries, env("PAYFAST_PASSPHRASE"), false) !== params.get("signature")) {
      return reply("Bad signature", 400);
    }

    // 2. Server-to-server confirmation with PayFast.
    const res = await fetch(payfastUrls(env("PAYFAST_MODE")).validate, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: paramString(entries, false),
    });
    if ((await res.text()).trim() !== "VALID") return reply("PayFast did not validate", 400);

    // 3. Business checks.
    if (params.get("merchant_id") !== env("PAYFAST_MERCHANT_ID")) return reply("Wrong merchant", 400);
    const plan = params.get("custom_str1") as PaidPlan | null;
    const companyId = params.get("custom_str2");
    if (!plan || !companyId || !(plan in PLANS)) return reply("Missing metadata", 400);

    const status = params.get("payment_status");
    let update: Record<string, string | null>;
    if (status === "COMPLETE") {
      if (Number(params.get("amount_gross")) !== Number(PLANS[plan].amount)) return reply("Amount mismatch", 400);
      update = { plan, payfast_token: params.get("token") };
    } else if (status === "CANCELLED") {
      update = { plan: "free" };
    } else {
      return reply("OK", 200); // PENDING / FAILED: nothing to change
    }

    const db = createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"));
    const { error } = await db.from("companies").update(update).eq("id", companyId);
    if (error) {
      console.error("plan update failed", error);
      return reply("DB error", 500); // non-200 makes PayFast retry
    }
    return reply("OK", 200);
  } catch (e) {
    console.error("payfast-webhook failed", e);
    return reply("Server error", 500);
  }
});
